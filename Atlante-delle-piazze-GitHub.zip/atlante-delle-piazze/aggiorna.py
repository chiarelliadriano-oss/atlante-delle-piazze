#!/usr/bin/env python3
"""Atlante delle piazze: aggiorna ogni ora i titoli delle città.

Legge data.json, cerca su Google News le notizie delle ultime ore per ogni città,
tiene solo testate gratuite di un elenco controllato (mai Il Tempo) e riscrive data.json.
Se una ricerca non va a buon fine, la città conserva i titoli che aveva.
"""
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo

ROME = ZoneInfo("Europe/Rome")
MESI = ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"]
MESI_L = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre"]
GIORNI = ["lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato", "domenica"]
PER_CITTA = 4
PAUSA = 1.2

# Testate gratuite ammesse, per dominio
GRATUITE = [
    # Italia
    "ansa.it", "ilpost.it", "open.online", "tg24.sky.it", "fanpage.it", "adnkronos.com", "rainews.it",
    "tgcom24.mediaset.it", "agi.it", "lapresse.it", "today.it", "milanotoday.it", "romatoday.it",
    "torinotoday.it", "bolognatoday.it", "firenzetoday.it", "genovatoday.it", "padovaoggi.it",
    "baritoday.it", "napolitoday.it", "agenzianova.com", "euronews.com",
    # agenzie e testate internazionali
    "reuters.com", "apnews.com", "aljazeera.com", "bbc.com", "bbc.co.uk", "dw.com", "france24.com",
    "rfi.fr", "balkaninsight.com", "n1info.rs", "n1info.com", "rferl.org", "khaleejtimes.com",
    # Francia
    "francetvinfo.fr", "franceinfo.fr", "20minutes.fr", "bfmtv.com", "huffingtonpost.fr", "actu.fr",
    "ici.fr", "francebleu.fr", "destimed.fr", "gomet.net",
    # Spagna
    "rtve.es", "eldiario.es", "20minutos.es", "europapress.es", "infobae.com", "publico.es",
    "elconfidencial.com", "cadenaser.com", "lasexta.com", "antena3.com", "telemadrid.es",
    # Portogallo
    "rtp.pt", "sicnoticias.pt", "cnnportugal.iol.pt", "tsf.pt", "noticiasaominuto.com", "abola.pt", "sapo.pt",
    # Belgio
    "rtbf.be", "lalibre.be", "7sur7.be", "vrt.be", "belganewsagency.eu",
    # Germania
    "tagesschau.de", "zdf.de", "zdfheute.de", "t-online.de", "rbb24.de", "ndr.de", "wdr.de", "br.de",
    "hessenschau.de", "mdr.de", "swr.de", "n-tv.de",
    # Grecia
    "ertnews.gr", "ert.gr", "ekathimerini.com", "tovima.com", "tovima.gr", "protothema.gr", "in.gr",
    "iefimerida.gr", "news247.gr",
    # Albania
    "euronews.al", "albaniandailynews.com", "exit.al", "tiranatimes.com", "top-channel.tv",
]
ESCLUSE = ["iltempo.it"]


def dominio(url):
    host = urllib.parse.urlparse(url or "").netloc.lower()
    return host[4:] if host.startswith("www.") else host


def ammessa(url):
    d = dominio(url)
    if not d or any(d == e or d.endswith("." + e) for e in ESCLUSE):
        return False
    return any(d == g or d.endswith("." + g) for g in GRATUITE)


def leggi_feed(xml_bytes):
    root = ET.fromstring(xml_bytes)
    voci = []
    for it in root.iter("item"):
        titolo = (it.findtext("title") or "").strip()
        link = (it.findtext("link") or "").strip()
        src = it.find("source")
        testata = (src.text or "").strip() if src is not None and src.text else ""
        sito = src.get("url", "") if src is not None else ""
        try:
            quando = parsedate_to_datetime(it.findtext("pubDate") or "")
        except (TypeError, ValueError):
            continue
        if quando.tzinfo is None:
            quando = quando.replace(tzinfo=timezone.utc)
        if testata and titolo.endswith(" - " + testata):
            titolo = titolo[: -len(testata) - 3].strip()
        if titolo and link:
            voci.append({"title": titolo, "url": link, "source": testata, "site": sito, "dt": quando})
    return voci


def cerca(q, ed):
    test = os.environ.get("ATLANTE_TEST_RSS")
    if test:
        with open(test, "rb") as f:
            return leggi_feed(f.read())
    url = "https://news.google.com/rss/search?" + urllib.parse.urlencode({"q": q, "hl": ed[0], "gl": ed[1], "ceid": ed[2]})
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Atlante delle piazze, aggiornamento orario)"})
    with urllib.request.urlopen(req, timeout=25) as r:
        return leggi_feed(r.read())


def ora_breve(dt):
    t = dt.astimezone(ROME)
    return f"{t.day} {MESI[t.month - 1]}, {t:%H:%M}"


def etichetta(dt):
    t = dt.astimezone(ROME)
    return f"{GIORNI[t.weekday()]} {t.day} {MESI_L[t.month - 1]} {t.year}, ore {t:%H:%M}"


def chiave(titolo):
    return re.sub(r"\W+", " ", titolo.lower()).strip()[:90]


def main(percorso="data.json"):
    with open(percorso, encoding="utf-8") as f:
        data = json.load(f)
    paesi = data["countries"]
    adesso = datetime.now(timezone.utc)
    riuscite = 0
    for c in data["cities"]:
        span = c.get("span") or "1d"
        limite = adesso - (timedelta(days=7) if span == "7d" else timedelta(hours=24))
        ricerche = [(f'"{c["name"]}" {paesi["it"]["kw"]} when:{span}', paesi["it"]["ed"])]
        if c["cc"] != "it":
            co = paesi[c["cc"]]
            ricerche.append((f'"{c["loc"]}" {co["kw"]} when:{span}', co["ed"]))
        trovate, errore = [], False
        for q, ed in ricerche:
            try:
                trovate += cerca(q, ed)
            except Exception as e:  # rete, limiti, feed malformato
                print(f"{c['id']}: ricerca non riuscita ({e})", file=sys.stderr)
                errore = True
            time.sleep(0 if os.environ.get("ATLANTE_TEST_RSS") else PAUSA)
        if errore and not trovate:
            continue
        visti, scelte = set(), []
        for v in sorted(trovate, key=lambda v: v["dt"], reverse=True):
            k = chiave(v["title"])
            if v["dt"] < limite or k in visti or not ammessa(v["site"]):
                continue
            visti.add(k)
            scelte.append({"time": ora_breve(v["dt"]), "title": v["title"], "source": v["source"], "url": v["url"]})
            if len(scelte) == PER_CITTA:
                break
        c["latest"] = scelte
        riuscite += 1
    if riuscite:
        data["news"] = {"iso": adesso.astimezone(ROME).isoformat(timespec="minutes"), "label": etichetta(adesso)}
    with open(percorso, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    print(f"città aggiornate: {riuscite} su {len(data['cities'])}")


if __name__ == "__main__":
    main(*sys.argv[1:])
